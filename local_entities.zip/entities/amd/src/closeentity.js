
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/*
 * @package    local_wunderbyte_table
 * @copyright  Wunderbyte GmbH <info@wunderbyte.at>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Gets called from mustache template.
 *
 */
export const init = () => {
    addEvents();
};


/**
 * toggles entitiy's open status
 */
function toggleEntity() {
    let catfieldsets = document.querySelectorAll('[id^=id_categorymeta]');
    Ajax.call([{
        methodname: "local_entities_update...",
        args: {
            'entitiyid': parseInt(userid),
            'open': ....;
        },
        done: function(data) {
            if (data.status == false) {
                return;
            }
        },
        fail: function(ex) {
            // eslint-disable-next-line no-console
            console.log("ex:" + ex);
        },
    }]);
}

/**
 * adds Evente to toggle switch
 */
function addEvents() {
    let select = document.getElementById('id_type');
    select.addEventListener('change', () => {
        toggleEntity();
    });
}
